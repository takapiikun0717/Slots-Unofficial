package com.ketheroth.slots.common.item;

import com.ketheroth.slots.common.utils.PlatformUtils;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SlotRewardItem extends Item {

	public SlotRewardItem() {
		super(new Item.Properties());
	}

	@Override
	public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
		SlotsSavedData.PlayerData playerData = SlotsSavedData.getPlayerUnlockedSlots(player);
		ItemStack itemStack = player.m_21120_(usedHand);
		if (playerData.getTotalUnlockedSlots() >= 54) {
			return InteractionResultHolder.m_19100_(itemStack);
		}
		if (level.f_46443_) {
			return InteractionResultHolder.m_19090_(itemStack);
		}
		player.m_213846_(Component.m_237113_("You gained 1 slot"));
		playerData.addUnremovableSlot();
		PlatformUtils.syncPlayerData(((ServerPlayer) player));
		return InteractionResultHolder.m_19096_(itemStack);
	}

}
