package com.ketheroth.slots.common.inventory.container;

import com.ketheroth.slots.common.registry.ModMenus;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class SlotsMenu extends AbstractContainerMenu {

	private SlotsSavedData.PlayerData playerData;


	public SlotsMenu(int windowId, Inventory playerInventory, Player player) {
		super(ModMenus.SLOTS_CONTAINER.get(), windowId);
		this.playerData = SlotsSavedData.getPlayerUnlockedSlots(player);
		// layout slots inventory
		int slot = 0;
		int size = this.playerData.inventory.m_6643_();
		while (slot < size) {
			int x = slot % 9;
			int y = slot / 9;
			this.m_38897_(new Slot(this.playerData.inventory, slot, 8 + 18 * x, 17 + 18 * y) {
				@Override
				public void m_5852_(ItemStack stack) {
					super.m_5852_(stack);
				}

				@Override
				public void m_142406_(Player player, ItemStack stack) {
					super.m_142406_(player, stack);
				}
			});
			slot++;
		}
//		});
		// layout player inventory
int rows = Math.min(6, (size + 8) / 9);
int playerInventoryY = 18 + rows * 18 + 14;

// layout player inventory
for (int y = 0; y < 3; y++) {
    for (int x = 0; x < 9; x++) {
        this.m_38897_(new Slot(playerInventory, 9 + 9 * y + x, 8 + 18 * x, playerInventoryY + 18 * y));
    }
}

for (int x = 0; x < 9; x++) {
    this.m_38897_(new Slot(
            playerInventory,
            x,
            8 + x * 18,
            playerInventoryY + 58
    ));
}
	}

	@Override
	public boolean m_6875_(Player player) {
		return this.playerData.inventory != null;
	}

	@Override
	public ItemStack m_7648_(Player player, int index) {
		ItemStack itemstack = ItemStack.f_41583_;
		Slot slot = this.f_38839_.get(index);
		int size = this.playerData.inventory.m_6643_();
		if (slot != null && slot.m_6657_()) {
			ItemStack slotStack = slot.m_7993_();
			itemstack = slotStack.m_41777_();
			if (0 <= index && index < size) {// shift-click from slots inventory
				if (!this.m_38903_(slotStack, size, 36 + size, true)) {
					return ItemStack.f_41583_;
				}
			} else if (size <= index && index < 36 + size) {// shift-click from player inventory
				if (!this.m_38903_(slotStack, 0, size, false)) {
					return ItemStack.f_41583_;
				}
			}

			if (slotStack.m_41619_()) {
				slot.m_5852_(ItemStack.f_41583_);
			} else {
				slot.m_6654_();
			}
			if (slotStack.m_41613_() == itemstack.m_41613_()) {
				return ItemStack.f_41583_;
			}
			slot.m_142406_(player, slotStack);
		}
		return itemstack;
	}

	public int getSlotAmount() {
		return this.playerData.inventory.m_6643_();
	}

}
