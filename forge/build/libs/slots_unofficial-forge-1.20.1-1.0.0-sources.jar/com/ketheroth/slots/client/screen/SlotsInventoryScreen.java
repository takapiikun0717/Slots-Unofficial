package com.ketheroth.slots.client.screen;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.inventory.container.SlotsMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class SlotsInventoryScreen extends AbstractContainerScreen<SlotsMenu> {

	private final ResourceLocation GUI =
        new ResourceLocation(Slots.MOD_ID, "textures/gui/slots_inventory.png");

    private final int slotAmount;

	public SlotsInventoryScreen(SlotsMenu menu, Inventory playerInventory, Component title) {
    super(menu, playerInventory, title);

    slotAmount = menu.getSlotAmount();

        int rows = (slotAmount + 8) / 9;

        this.f_97726_ = 176;
        this.f_97727_ = 114 + rows * 18;

        int playerInventoryY = 18 + rows * 18 + 14;
        this.f_97731_ = playerInventoryY - 10;
    
}

	@Override
	public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
		this.m_280273_(guiGraphics);
		super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
		this.m_280072_(guiGraphics, mouseX, mouseY);
		// TODO: @ketheroth render next slot to unlock "unlock this slot by having x xp levels"
	}

	@Override
    protected void m_7286_(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {

    int rows = Math.min(6, (slotAmount + 8) / 9);

    int left = (this.f_96543_ - this.f_97726_) / 2;
    int top = (this.f_96544_ - this.f_97727_) / 2;

    // 上側（背景）
    guiGraphics.m_280218_(
            GUI,
            left,
            top,
            0,
            0,
            176,
            17 + rows * 18
    );

    // 下側（プレイヤーインベントリ）
    guiGraphics.m_280218_(
            GUI,
            left,
            top + 17 + rows * 18,
            0,
            126,
            176,
            96
    );

    // 解放済みスロットだけ枠を描画
    for (int i = 0; i < slotAmount; i++) {

        int x = i % 9;
        int y = i / 9;

        guiGraphics.m_280218_(
                GUI,
                left + 7 + x * 18,
                top + 17 + y * 18,
                0,
                238,
                18,
                18
        );
    }
}
}