package com.ketheroth.slots.client;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.client.keymapping.SlotKeyMapping;
import com.ketheroth.slots.common.network.OpenSlotPacket;
import com.ketheroth.slots.common.networking.SlotsPacketHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.NetworkDirection;

@Mod.EventBusSubscriber(
        modid = Slots.MOD_ID,
        bus = Mod.EventBusSubscriber.Bus.FORGE,
        value = Dist.CLIENT
)
public class ClientEvents {

    @SubscribeEvent
    public static void onKeyPress(InputEvent.Key event) {
        if (SlotKeyMapping.KEY_OPEN.m_90857_()) {
            LocalPlayer player = Minecraft.m_91087_().f_91074_;
            if (player != null) {
                SlotsPacketHandler.INSTANCE.sendTo(
                        new OpenSlotPacket(),
                        player.f_108617_.m_104910_(),
                        NetworkDirection.PLAY_TO_SERVER
                );
            }
        }
    }
}