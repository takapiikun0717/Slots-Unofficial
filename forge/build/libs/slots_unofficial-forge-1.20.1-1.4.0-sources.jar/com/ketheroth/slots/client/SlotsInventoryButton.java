package com.ketheroth.slots.client;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.network.OpenSlotPacket;
import com.ketheroth.slots.common.networking.SlotsPacketHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;

public class SlotsInventoryButton extends ImageButton {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Slots.MOD_ID, "textures/gui/button.png");

    public SlotsInventoryButton(int x, int y) {
        super(
                x,
                y,
                15,
                15,
                0,
                0,
                15,
                TEXTURE,
                15,
                30,
                button -> {

                    LocalPlayer player = Minecraft.m_91087_().f_91074_;

                    if (player != null) {
                        SlotsPacketHandler.INSTANCE.sendTo(
                                new OpenSlotPacket(),
                                player.f_108617_.m_104910_(),
                                NetworkDirection.PLAY_TO_SERVER
                        );
                    }

                },
                Component.m_237113_("Open Slots")
        );
    }

    @Override
    public void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.m_87963_(guiGraphics, mouseX, mouseY, partialTick);
    }
    @Override
    public void m_5691_() {
        super.m_5691_();
    }

}