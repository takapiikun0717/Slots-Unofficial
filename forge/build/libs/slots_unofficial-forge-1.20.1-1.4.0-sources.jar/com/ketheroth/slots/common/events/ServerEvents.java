package com.ketheroth.slots.common.events;

import com.ketheroth.slots.common.utils.PlatformUtils;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;

public class ServerEvents {

	public static void onPlayerDeath(LivingEntity entity, DamageSource damageSource) {
    if (entity instanceof ServerPlayer player) {

        // KeepInventoryが有効ならスロットはロックしない
        if (player.m_9236_().m_46469_().m_46207_(GameRules.f_46133_)) {
            return;
        }

        SlotsSavedData.PlayerData playerData = SlotsSavedData.getPlayerUnlockedSlots(player);

        for (ItemStack stack : playerData.inventory.m_19195_()) {
            ItemEntity itementity = new ItemEntity(
                    player.m_9236_(),
                    player.m_20185_(),
                    player.m_20188_(),
                    player.m_20189_(),
                    stack
            );
            itementity.m_32010_(40);
            itementity.m_32052_(player.m_20148_());
            player.m_9236_().m_7967_(itementity);
        }

        playerData.resetAfterDeath();
        PlatformUtils.syncPlayerData(player);
    }
}

}
