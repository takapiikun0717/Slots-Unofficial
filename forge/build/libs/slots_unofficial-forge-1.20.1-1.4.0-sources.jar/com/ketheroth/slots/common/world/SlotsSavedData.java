package com.ketheroth.slots.common.world;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.config.SlotsConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;

import java.util.HashMap;
import java.util.UUID;

public class SlotsSavedData extends SavedData {

	public static PlayerData clientData = new PlayerData();


	public HashMap<UUID, PlayerData> players = new HashMap<>();

	public static PlayerData getPlayerUnlockedSlots(LivingEntity player) {
		if (player.m_9236_().f_46443_) {
			return clientData;
		}
		return getServerData(player.m_20194_()).players.computeIfAbsent(player.m_20148_(), uuid -> new PlayerData());
	}


	public static SlotsSavedData getServerData(MinecraftServer server) {
		DimensionDataStorage dataStorage = server.m_129880_(Level.f_46428_).m_8895_();
		SlotsSavedData state = dataStorage.m_164861_(SlotsSavedData::createFromTag, SlotsSavedData::new, Slots.MOD_ID);
		state.m_77762_();
		return state;
	}

	public static SlotsSavedData createFromTag(CompoundTag tag) {
		SlotsSavedData state = new SlotsSavedData();
		CompoundTag playersTag = tag.m_128469_("Players");
		playersTag.m_128431_().forEach(key -> {
			CompoundTag compound = playersTag.m_128469_(key);
			PlayerData playerData = new PlayerData();
			playerData.load(compound);
			state.players.put(UUID.fromString(key), playerData);
		});
		return state;
	}

	@Override
	public CompoundTag m_7176_(CompoundTag tag) {
		CompoundTag playersTag = new CompoundTag();
		players.forEach((uuid, playerData) -> {
			CompoundTag data = new CompoundTag();
			playerData.save(data);
			playersTag.m_128365_(uuid.toString(), data);
		});
		tag.m_128365_("Players", playersTag);
		return tag;
	}

	public static class PlayerData {

		public SimpleContainer inventory;
		private int unlockedSlots;
		private int unremovableSlots;

		public PlayerData() {
			this(0, 0);
		}

		public PlayerData(int unlockedSlots, int unremovableSlots) {
            this.unlockedSlots = unlockedSlots;
            this.unremovableSlots = unremovableSlots;
            this.inventory = new SimpleContainer(unlockedSlots);
        }

		public void addSlot() {

			if (this.unlockedSlots >= SlotsConfig.getMaxUnlockedSlots()) {
                return;
            }
			

    if (this.unlockedSlots >= 54) {
        return;
    }

    this.unlockedSlots++;

    SimpleContainer inv = new SimpleContainer(this.unlockedSlots);

    for (int i = 0; i < this.inventory.m_6643_(); i++) {
        inv.m_6836_(i, this.inventory.m_8020_(i));
    }

    this.inventory = inv;
}

		public void addUnremovableSlot() {
			this.addSlot();
			this.unremovableSlots++;
		}

		public void load(CompoundTag tag) {
            this.unlockedSlots = Math.min(54, tag.m_128451_("UnlockedSlots"));
            this.unremovableSlots = Math.min(54, tag.m_128451_("UnremovableSlots"));

            this.inventory = new SimpleContainer(this.unlockedSlots);
            this.inventory.m_7797_(tag.m_128437_("Inventory", Tag.f_178203_));
        }

		public void save(CompoundTag tag) {
			tag.m_128405_("UnlockedSlots", this.unlockedSlots);
			tag.m_128405_("UnremovableSlots", this.unremovableSlots);
			ListTag inv = this.inventory.m_7927_();
			tag.m_128365_("Inventory", inv);
		}

		public int getTotalUnlockedSlots() {
			return this.unlockedSlots;
		}

		public int getXpUnlockedSlots() {
			return this.unlockedSlots - this.unremovableSlots;
		}

		public ItemStack removeSlot() {
			if (this.unlockedSlots > this.unremovableSlots) {
				this.unlockedSlots--;
				SimpleContainer inv = new SimpleContainer(unlockedSlots);
				for (int i = 0; i < this.inventory.m_6643_() - 1; i++) {
					inv.m_6836_(i, this.inventory.m_8020_(i));
				}
				ItemStack stack = this.inventory.m_7407_(this.unlockedSlots, this.inventory.m_6893_());
				this.inventory = inv;
				return stack;
			}
			return ItemStack.f_41583_;
		}

		public void resetAfterDeath() {
			if (SlotsConfig.preserveRewardsOnDeath) {
				this.unlockedSlots = this.unremovableSlots;
			} else {
				this.unlockedSlots = 0;
				this.unremovableSlots = 0;
			}
			this.inventory = new SimpleContainer(this.unlockedSlots);
		}

	}

}
