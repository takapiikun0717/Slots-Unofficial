package com.ketheroth.slots.platform;

import java.util.function.Supplier;
import net.minecraft.class_2960;

public interface WrappedEntry<T> extends Supplier<T> {

//	@Override
//	T get();

	class_2960 getId();

}