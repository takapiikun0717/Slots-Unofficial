package com.ketheroth.slots.platform.fabric;

import com.ketheroth.slots.platform.WrappedRegistry;
import net.minecraft.class_2378;

public class WrappedRegistriesImpl {

	public static <T> WrappedRegistry<T> create(class_2378<T> registry, String modid) {
		return new FabricWrappedRegistry<>(registry, modid);
	}

}
