package com.ketheroth.slots.platform.fabric;

import com.ketheroth.slots.platform.WrappedEntry;
import net.minecraft.class_2960;

public class FabricWrappedEntry<T> implements WrappedEntry<T> {

	private final class_2960 id;
	private final T object;

	public FabricWrappedEntry(class_2960 id, T object) {
		this.id = id;
		this.object = object;
	}

	@Override
	public class_2960 getId() {
		return id;
	}

	@Override
	public T get() {
		return object;
	}

}
