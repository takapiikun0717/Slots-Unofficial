package com.ketheroth.slots.platform.fabric;

import com.ketheroth.slots.platform.WrappedEntry;
import com.ketheroth.slots.platform.WrappedRegistry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class FabricWrappedRegistry<T> implements WrappedRegistry<T> {

	private final class_2378<T> registry;
	private final String modid;
	private final List<WrappedEntry<T>> entries;

	public FabricWrappedRegistry(class_2378<T> registry, String modid) {
		this.registry = registry;
		this.modid = modid;
		entries = new ArrayList<>();
	}

	@Override
	public <I extends T> WrappedEntry<I> register(String id, Supplier<I> supplier) {
		class_2960 rl = new class_2960(this.modid, id);
		I object = class_2378.method_10230(this.registry, rl, supplier.get());
		FabricWrappedEntry<I> entry = new FabricWrappedEntry<>(rl, object);
		entries.add((WrappedEntry<T>) entry);
		return entry;
	}

	@Override
	public Collection<WrappedEntry<T>> getEntries() {
		return entries;
	}

	@Override
	public void init() {
	}

}
