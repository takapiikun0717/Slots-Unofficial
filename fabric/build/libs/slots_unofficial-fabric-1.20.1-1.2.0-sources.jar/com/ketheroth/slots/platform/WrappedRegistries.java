package com.ketheroth.slots.platform;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_2378;
import org.apache.commons.lang3.NotImplementedException;

public class WrappedRegistries {

	@ExpectPlatform
	public static <T> WrappedRegistry<T> create(class_2378<T> registry, String modid) {
		throw new NotImplementedException();
	}

}
