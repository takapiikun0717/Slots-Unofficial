package com.ketheroth.slots.common.events;

import com.ketheroth.slots.common.utils.PlatformUtils;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public class ServerEvents {

	public static void onPlayerDeath(class_1309 entity, class_1282 damageSource) {
		if (entity instanceof class_3222 player) {
			SlotsSavedData.PlayerData playerData = SlotsSavedData.getPlayerUnlockedSlots(player);
			for (class_1799 stack : playerData.inventory.method_24514()) {
				class_1542 itementity = new class_1542(player.method_37908(), player.method_23317(), player.method_23320(), player.method_23321(), stack);
				itementity.method_6982(40);
				itementity.method_6981(player.method_5667());
				player.method_37908().method_8649(itementity);
			}
			playerData.resetAfterDeath();
			PlatformUtils.syncPlayerData(player);
		}
	}

}
