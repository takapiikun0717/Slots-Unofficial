package com.ketheroth.slots.common.network;

import com.ketheroth.slots.Slots;
import net.minecraft.class_2960;

public class NetworkingConstants {
public static final class_2960 OPEN_SLOTS_ID = new class_2960(Slots.MOD_ID, "open_slots");
}
