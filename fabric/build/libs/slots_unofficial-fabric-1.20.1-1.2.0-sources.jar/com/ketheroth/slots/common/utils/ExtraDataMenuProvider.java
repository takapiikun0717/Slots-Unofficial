package com.ketheroth.slots.common.utils;

import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

/**
 * A menu provider that can be used to send extra data to the client.
 */
public interface ExtraDataMenuProvider extends class_3908 {

	/**
	 * Writes the extra data to the buffer to be sent to the client when the menu is opened.
	 *
	 * @param player The player that is opening the menu.
	 * @param buffer The buffer to write the data to.
	 */
	void writeExtraData(class_3222 player, class_2540 buffer);

}
