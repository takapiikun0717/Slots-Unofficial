package com.ketheroth.slots.common.network;

import com.ketheroth.slots.common.inventory.container.SlotsMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3908;

// from client to server
public class OpenSlotPacket implements HandledPacket {

	@Override
	public void write(class_2540 buf) {

	}

	@Override
	public void read(class_2540 buf) {

	}

	@Override
	public void handle(class_1657 player) {
		player.method_17355(new class_3908() {
			@Override
			public class_2561 method_5476() {
				return class_2561.method_43471("screen.slots.slots_inventory");
			}

			@Override
			public class_1703 createMenu(int i, class_1661 inventory, class_1657 player) {
				return new SlotsMenu(i, inventory, player);
			}
		});
	}

}
