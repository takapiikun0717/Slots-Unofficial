package com.ketheroth.slots.common.utils;

import com.ketheroth.slots.common.network.HandledPacket;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_2378;
import net.minecraft.class_3222;
import org.apache.commons.lang3.NotImplementedException;

public class PlatformUtils {

	@ExpectPlatform
	public static void syncPlayerData(class_3222 player) {
		throw new NotImplementedException();
	}


	@ExpectPlatform
	public static <T> void createRegistry(class_2378<T> registry, String id) {
		throw new NotImplementedException();
	}


}
