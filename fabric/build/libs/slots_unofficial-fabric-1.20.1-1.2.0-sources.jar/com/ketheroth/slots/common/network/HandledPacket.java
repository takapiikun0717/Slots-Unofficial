package com.ketheroth.slots.common.network;

import net.minecraft.class_1657;
import net.minecraft.class_2540;

public interface HandledPacket {

	void write(class_2540 buf);

	void read(class_2540 buf);

	void handle(class_1657 player);

}
