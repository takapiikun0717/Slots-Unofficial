package com.ketheroth.slots.common.network;

import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2540;

// from server to client
public class SyncPlayerDataPacket implements HandledPacket {

	public SlotsSavedData.PlayerData playerData;

	public SyncPlayerDataPacket() {
	}

	public SyncPlayerDataPacket(SlotsSavedData.PlayerData playerData) {
		this.playerData = playerData;
	}

	@Override
	public void write(class_2540 buf) {
		class_2487 tag = new class_2487();
		this.playerData.save(tag);
		buf.method_10794(tag);
	}

	@Override
	public void read(class_2540 buf) {
		class_2487 tag = buf.method_10798();
		this.playerData = new SlotsSavedData.PlayerData();
		if (tag != null) {
			this.playerData.load(tag);
		}
	}


	@Override
	public void handle(class_1657 player) {
		SlotsSavedData.clientData = this.playerData;
	}

}
