package com.ketheroth.slots.common.registry;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.item.SlotRewardItem;
import com.ketheroth.slots.platform.WrappedEntry;
import com.ketheroth.slots.platform.WrappedRegistries;
import com.ketheroth.slots.platform.WrappedRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_7923;

public class ModItems {

	public static final WrappedRegistry<class_1792> ITEMS = WrappedRegistries.create(class_7923.field_41178, Slots.MOD_ID);

	public static final WrappedEntry<class_1792> SLOT_REWARD = ITEMS.register("slot_reward", SlotRewardItem::new);

}
