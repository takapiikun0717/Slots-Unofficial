package com.ketheroth.slots.common.item;

import com.ketheroth.slots.common.utils.PlatformUtils;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class SlotRewardItem extends class_1792 {

	public SlotRewardItem() {
		super(new class_1792.class_1793());
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
		SlotsSavedData.PlayerData playerData = SlotsSavedData.getPlayerUnlockedSlots(player);
		class_1799 itemStack = player.method_5998(usedHand);
		if (playerData.getTotalUnlockedSlots() >= 54) {
			return class_1271.method_22431(itemStack);
		}
		if (level.field_9236) {
			return class_1271.method_22427(itemStack);
		}
		player.method_43496(class_2561.method_43470("You gained 1 slot"));
		playerData.addUnremovableSlot();
		PlatformUtils.syncPlayerData(((class_3222) player));
		return class_1271.method_22428(itemStack);
	}

}
