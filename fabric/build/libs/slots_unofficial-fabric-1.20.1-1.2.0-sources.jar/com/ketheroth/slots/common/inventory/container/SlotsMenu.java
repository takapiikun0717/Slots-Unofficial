package com.ketheroth.slots.common.inventory.container;

import com.ketheroth.slots.common.registry.ModMenus;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class SlotsMenu extends class_1703 {

	private SlotsSavedData.PlayerData playerData;


	public SlotsMenu(int windowId, class_1661 playerInventory, class_1657 player) {
		super(ModMenus.SLOTS_CONTAINER.get(), windowId);
		this.playerData = SlotsSavedData.getPlayerUnlockedSlots(player);
		// layout slots inventory
		int slot = 0;
		int size = this.playerData.inventory.method_5439();
		while (slot < size) {
			int x = slot % 9;
			int y = slot / 9;
			this.method_7621(new class_1735(this.playerData.inventory, slot, 8 + 18 * x, 17 + 18 * y) {
				@Override
				public void method_7673(class_1799 stack) {
					super.method_7673(stack);
				}

				@Override
				public void method_7667(class_1657 player, class_1799 stack) {
					super.method_7667(player, stack);
				}
			});
			slot++;
		}
//		});
		// layout player inventory
int rows = Math.min(6, (size + 8) / 9);
int playerInventoryY = 18 + rows * 18 + 14;

// layout player inventory
for (int y = 0; y < 3; y++) {
    for (int x = 0; x < 9; x++) {
        this.method_7621(new class_1735(playerInventory, 9 + 9 * y + x, 8 + 18 * x, playerInventoryY + 18 * y));
    }
}

for (int x = 0; x < 9; x++) {
    this.method_7621(new class_1735(
            playerInventory,
            x,
            8 + x * 18,
            playerInventoryY + 58
    ));
}
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return this.playerData.inventory != null;
	}

	@Override
	public class_1799 method_7601(class_1657 player, int index) {
		class_1799 itemstack = class_1799.field_8037;
		class_1735 slot = this.field_7761.get(index);
		int size = this.playerData.inventory.method_5439();
		if (slot != null && slot.method_7681()) {
			class_1799 slotStack = slot.method_7677();
			itemstack = slotStack.method_7972();
			if (0 <= index && index < size) {// shift-click from slots inventory
				if (!this.method_7616(slotStack, size, 36 + size, true)) {
					return class_1799.field_8037;
				}
			} else if (size <= index && index < 36 + size) {// shift-click from player inventory
				if (!this.method_7616(slotStack, 0, size, false)) {
					return class_1799.field_8037;
				}
			}

			if (slotStack.method_7960()) {
				slot.method_7673(class_1799.field_8037);
			} else {
				slot.method_7668();
			}
			if (slotStack.method_7947() == itemstack.method_7947()) {
				return class_1799.field_8037;
			}
			slot.method_7667(player, slotStack);
		}
		return itemstack;
	}

	public int getSlotAmount() {
		return this.playerData.inventory.method_5439();
	}

}
