package com.ketheroth.slots.common.registry;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.inventory.container.SlotsMenu;
import com.ketheroth.slots.platform.WrappedEntry;
import com.ketheroth.slots.platform.WrappedRegistries;
import com.ketheroth.slots.platform.WrappedRegistry;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public class ModMenus {

	public static final WrappedRegistry<class_3917<?>> MENUS = WrappedRegistries.create(class_7923.field_41187, Slots.MOD_ID);

	public static final WrappedEntry<class_3917<SlotsMenu>> SLOTS_CONTAINER = MENUS.register("slots_container",() -> new class_3917<>((i, inventory) -> new SlotsMenu(i, inventory, inventory.field_7546), class_7701.field_40182));

}
