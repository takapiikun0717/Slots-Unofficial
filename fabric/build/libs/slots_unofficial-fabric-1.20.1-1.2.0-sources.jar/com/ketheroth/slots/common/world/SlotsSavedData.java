package com.ketheroth.slots.common.world;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.config.SlotsConfig;
import net.minecraft.class_1277;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_26;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.UUID;

public class SlotsSavedData extends class_18 {

	public static PlayerData clientData = new PlayerData();


	public HashMap<UUID, PlayerData> players = new HashMap<>();

	public static PlayerData getPlayerUnlockedSlots(class_1309 player) {
		if (player.method_37908().field_9236) {
			return clientData;
		}
		return getServerData(player.method_5682()).players.computeIfAbsent(player.method_5667(), uuid -> new PlayerData());
	}


	public static SlotsSavedData getServerData(MinecraftServer server) {
		class_26 dataStorage = server.method_3847(class_1937.field_25179).method_17983();
		SlotsSavedData state = dataStorage.method_17924(SlotsSavedData::createFromTag, SlotsSavedData::new, Slots.MOD_ID);
		state.method_80();
		return state;
	}

	public static SlotsSavedData createFromTag(class_2487 tag) {
		SlotsSavedData state = new SlotsSavedData();
		class_2487 playersTag = tag.method_10562("Players");
		playersTag.method_10541().forEach(key -> {
			class_2487 compound = playersTag.method_10562(key);
			PlayerData playerData = new PlayerData();
			playerData.load(compound);
			state.players.put(UUID.fromString(key), playerData);
		});
		return state;
	}

	@Override
	public class_2487 method_75(class_2487 tag) {
		class_2487 playersTag = new class_2487();
		players.forEach((uuid, playerData) -> {
			class_2487 data = new class_2487();
			playerData.save(data);
			playersTag.method_10566(uuid.toString(), data);
		});
		tag.method_10566("Players", playersTag);
		return tag;
	}

	public static class PlayerData {

		public class_1277 inventory;
		private int unlockedSlots;
		private int unremovableSlots;

		public PlayerData() {
			this(0, 0);
		}

		public PlayerData(int unlockedSlots, int unremovableSlots) {
            this.unlockedSlots = unlockedSlots;
            this.unremovableSlots = unremovableSlots;
            this.inventory = new class_1277(unlockedSlots);
        }

		public void addSlot() {

    if (this.unlockedSlots >= 54) {
        return;
    }

    this.unlockedSlots++;

    class_1277 inv = new class_1277(this.unlockedSlots);

    for (int i = 0; i < this.inventory.method_5439(); i++) {
        inv.method_5447(i, this.inventory.method_5438(i));
    }

    this.inventory = inv;
}

		public void addUnremovableSlot() {
			this.addSlot();
			this.unremovableSlots++;
		}

		public void load(class_2487 tag) {
            this.unlockedSlots = Math.min(54, tag.method_10550("UnlockedSlots"));
            this.unremovableSlots = Math.min(54, tag.method_10550("UnremovableSlots"));

            this.inventory = new class_1277(this.unlockedSlots);
            this.inventory.method_7659(tag.method_10554("Inventory", class_2520.field_33260));
        }

		public void save(class_2487 tag) {
			tag.method_10569("UnlockedSlots", this.unlockedSlots);
			tag.method_10569("UnremovableSlots", this.unremovableSlots);
			class_2499 inv = this.inventory.method_7660();
			tag.method_10566("Inventory", inv);
		}

		public int getTotalUnlockedSlots() {
			return this.unlockedSlots;
		}

		public int getXpUnlockedSlots() {
			return this.unlockedSlots - this.unremovableSlots;
		}

		public class_1799 removeSlot() {
			if (this.unlockedSlots > this.unremovableSlots) {
				this.unlockedSlots--;
				class_1277 inv = new class_1277(unlockedSlots);
				for (int i = 0; i < this.inventory.method_5439() - 1; i++) {
					inv.method_5447(i, this.inventory.method_5438(i));
				}
				class_1799 stack = this.inventory.method_5434(this.unlockedSlots, this.inventory.method_5444());
				this.inventory = inv;
				return stack;
			}
			return class_1799.field_8037;
		}

		public void resetAfterDeath() {
			if (SlotsConfig.preserveRewardsOnDeath) {
				this.unlockedSlots = this.unremovableSlots;
			} else {
				this.unlockedSlots = 0;
				this.unremovableSlots = 0;
			}
			this.inventory = new class_1277(this.unlockedSlots);
		}

	}

}
