package com.ketheroth.slots.fabric;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.config.SlotsConfig;
import com.ketheroth.slots.common.events.ServerEvents;
import com.ketheroth.slots.common.networking.FabricOpenSlotPacket;
import com.ketheroth.slots.common.networking.FabricSyncPlayerDataPacket;
import com.ketheroth.slots.common.registry.ModItems;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import java.util.List;

public class SlotsFabric implements ModInitializer {

	public static final List<class_2960> VALID_LOOT_TABLES = List.of(new class_2960("minecraft", "chests/abandoned_mineshaft"),
			new class_2960("minecraft", "chests/buried_treasure"),
			new class_2960("minecraft", "chests/end_city_treasure"),
			new class_2960("minecraft", "chests/shipwreck_treasure"),
			new class_2960("minecraft", "chests/simple_dungeon"),
			new class_2960("minecraft", "chests/stronghold_corridor"),
			new class_2960("minecraft", "chests/stronghold_crossing"));


	@Override
	public void onInitialize() {
		Slots.init();
		ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(content -> content.accept(ModItems.SLOT_REWARD.get()));
		ServerPlayNetworking.registerGlobalReceiver(FabricOpenSlotPacket.TYPE, (openSlotPacket, player, responseSender) -> openSlotPacket.handle(player));
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			SlotsSavedData.PlayerData playerData = SlotsSavedData.getPlayerUnlockedSlots(handler.player);
			server.execute(() -> ServerPlayNetworking.send(handler.player, new FabricSyncPlayerDataPacket(playerData)));
		});
		ServerLivingEntityEvents.AFTER_DEATH.register(ServerEvents::onPlayerDeath);
		LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
			if (SlotsConfig.generateItemReward && VALID_LOOT_TABLES.contains(id) && source.isBuiltin()) {
				LootPool pool = LootPool.lootPool()
						.with(LootItem.lootTableItem(ModItems.SLOT_REWARD.get()).build())
						.conditionally(LootItemRandomChanceCondition.randomChance(0.66F).build())
						.build();
				tableBuilder.pool(pool);
			}
		});
	}

}
