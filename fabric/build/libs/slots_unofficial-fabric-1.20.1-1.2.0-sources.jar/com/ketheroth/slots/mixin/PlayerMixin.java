package com.ketheroth.slots.mixin;

import com.ketheroth.slots.common.config.SlotsConfig;
import com.ketheroth.slots.common.networking.FabricSyncPlayerDataPacket;
import com.ketheroth.slots.common.world.SlotsSavedData;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public abstract class PlayerMixin {

	private static void addOrDropItems(class_1657 player, class_1799 stack) {
		if (!player.method_31548().method_7394(stack)) {
			// can't add to player inventory, drop the item
			class_1542 itementity = new class_1542(player.method_37908(), player.method_23317(), player.method_23320(), player.method_23321(), stack);
			itementity.method_6982(40);
			itementity.method_6981(player.method_5667());
			player.method_37908().method_8649(itementity);
		}
	}

	@Inject(method = "giveExperienceLevels", at = @At("TAIL"))
	private void onLevelAdded(int levels, CallbackInfo ci) {
		class_1657 player = (class_1657) (Object) this;
		if (player.method_37908().field_9236) {
			return;
		}
		SlotsSavedData.PlayerData playerData = SlotsSavedData.getPlayerUnlockedSlots(player);
		int newSlotAmount = player.field_7520 / SlotsConfig.levelPerSlot;
		int delta = newSlotAmount - playerData.getXpUnlockedSlots();
		if (delta == 0) {
			return;
		}
		if (delta > 0) {
			for (int i = 0; i < delta; i++) {
				playerData.addSlot();
			}
		} else {
			for (int i = delta; i < 0; i++) {
				class_1799 stack = playerData.removeSlot();
				if (!stack.method_7960()) {
					addOrDropItems(player, stack);
				}
			}
		}
		if (player instanceof class_3222 serverPlayer) {
			serverPlayer.field_13995.execute(() -> ServerPlayNetworking.send(serverPlayer, new FabricSyncPlayerDataPacket(playerData)));
		}
	}

}
