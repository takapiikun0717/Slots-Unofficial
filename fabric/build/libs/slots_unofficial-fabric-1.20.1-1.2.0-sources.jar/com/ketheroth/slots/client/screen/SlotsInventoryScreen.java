package com.ketheroth.slots.client.screen;

import com.ketheroth.slots.Slots;
import com.ketheroth.slots.common.inventory.container.SlotsMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class SlotsInventoryScreen extends class_465<SlotsMenu> {

	private final class_2960 GUI =
        new class_2960(Slots.MOD_ID, "textures/gui/slots_inventory.png");

    private final int slotAmount;

	public SlotsInventoryScreen(SlotsMenu menu, class_1661 playerInventory, class_2561 title) {
    super(menu, playerInventory, title);

    slotAmount = menu.getSlotAmount();

        int rows = (slotAmount + 8) / 9;

        this.field_2792 = 176;
        this.field_2779 = 114 + rows * 18;

        int playerInventoryY = 18 + rows * 18 + 14;
        this.field_25270 = playerInventoryY - 10;
    
}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		this.method_25420(guiGraphics);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		this.method_2380(guiGraphics, mouseX, mouseY);
		// TODO: @ketheroth render next slot to unlock "unlock this slot by having x xp levels"
	}

	@Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {

    int rows = Math.min(6, (slotAmount + 8) / 9);

    int left = (this.field_22789 - this.field_2792) / 2;
    int top = (this.field_22790 - this.field_2779) / 2;

    // 上側（背景）
    guiGraphics.method_25302(
            GUI,
            left,
            top,
            0,
            0,
            176,
            17 + rows * 18
    );

    // 下側（プレイヤーインベントリ）
    guiGraphics.method_25302(
            GUI,
            left,
            top + 17 + rows * 18,
            0,
            126,
            176,
            96
    );

    // 解放済みスロットだけ枠を描画
    for (int i = 0; i < slotAmount; i++) {

        int x = i % 9;
        int y = i / 9;

        guiGraphics.method_25302(
                GUI,
                left + 7 + x * 18,
                top + 17 + y * 18,
                0,
                238,
                18,
                18
        );
    }
}
}