package com.ketheroth.slots.client.keymapping;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_746;

public class SlotKeyMapping {

	public static final class_304 KEY_OPEN = new class_304("key.slots.inventory", class_3675.field_31914, "slots.key.category");

	public static void handleKeyPress(class_746 player) {
		if (KEY_OPEN.method_1434()) {
		}
	}
}
